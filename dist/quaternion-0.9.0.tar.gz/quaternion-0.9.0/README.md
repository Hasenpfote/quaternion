Quaternion
==========

## About  
This package provides a class for manipulating quaternion objects.

## Compatibility  
* Python 3.x

## Installation  
    python setup.py install

## License  
This software is released under the MIT License, see LICENSE.
