Quaternion
==========

## About  
This package provides a class for manipulating quaternion objects.

## Compatibility  
* Python 3.x

## Installation  
    python setup.py install

or  

    pip install dist/quaternion-0.9.0.tar.gz

## License  
This software is released under the MIT License, see LICENSE.
